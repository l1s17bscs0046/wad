<?php
$con = mysqli_connect("localhost","root","","techboxdb");
if(!$con)
    die("Connection failed");